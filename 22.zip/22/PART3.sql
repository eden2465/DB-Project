--DB BUILDING
CREATE TABLE STORES (
    Mail VARCHAR(200) NOT NULL PRIMARY KEY,
    Phone VARCHAR(30) NOT NULL,
    Name VARCHAR(20) NOT NULL,
    Country VARCHAR(20) NOT NULL,
    DeliveryArea VARCHAR(20) NOT NULL,
    NumberOfShops INTEGER NOT NULL
)

CREATE TABLE SEARCHES (
    IPAddress VARCHAR(20) NOT NULL,
    SearchDT DATETIME NOT NULL,
    SearchKeyWord VARCHAR(70) NOT NULL,
    Mail VARCHAR(200) NULL,
    PRIMARY KEY (IPAddress, SearchDT)
)

CREATE TABLE REVIEWS (
    Mail VARCHAR(200) NOT NULL,
    ReviewDT DATETIME NOT NULL,
    NickName VARCHAR(20) NOT NULL,
    Rating SMALLINT NOT NULL,
    Summary VARCHAR(20) NOT NULL,
    Description VARCHAR(400) NOT NULL,
    ProductID INTEGER NOT NULL,
    PRIMARY KEY (Mail, ReviewDT)
)

CREATE TABLE PRODUCTS (
    ProductID INTEGER NOT NULL PRIMARY KEY,
    Name VARCHAR(70) NOT NULL,
    Details VARCHAR(400) NOT NULL
)

CREATE TABLE RECIPIENTS (
    PhoneNumber VARCHAR(30) NOT NULL PRIMARY KEY, 
    [Name-First] VARCHAR(20),
    [Name-Last] VARCHAR(20),
)

CREATE TABLE DETAILS (
    ProductID INTEGER NOT NULL, 
    OrderID INTEGER NOT NULL, 
    TextCard VARCHAR(200),
    Quantity SMALLINT NOT NULL,
    Size VARCHAR(10) NOT NULL,
    PRIMARY KEY (ProductID, OrderID)
)



CREATE TABLE PRICINGS (
    ProductID INTEGER NOT NULL,
    Mail VARCHAR(200) NOT NULL,
    Price MONEY NOT NULL,
	Primary key ( ProductID,mail)
)

CREATE TABLE RESULTS (
    IPAddress VARCHAR(20) NOT NULL, 
    SearchDT DATETIME NOT NULL,
    ProductID INTEGER NOT NULL,
    PRIMARY KEY (IPAddress, SearchDT, ProductID)
)

CREATE TABLE CUSTOMERS (
    Mail VARCHAR(200) NOT NULL PRIMARY KEY,
    Password VARCHAR(20) NOT NULL,
    [Name-First] VARCHAR(20) NOT NULL,
    [Name-Last] VARCHAR(20) NOT NULL
)

CREATE TABLE ORDERS (
    OrderID INTEGER NOT NULL PRIMARY KEY,
    WantedArrivalDate DATE NOT NULL,
    TransactionDT DATETIME NOT NULL,
    CCNumber VARCHAR(20) NOT NULL,
    PhoneNumber VARCHAR(30) NOT NULL,
    Mail VARCHAR(200) NOT NULL,
    [Address-Country] VARCHAR(20) NOT NULL,
    [Address-City] VARCHAR(20) NOT NULL,
    [Address-Street] VARCHAR(100) NOT NULL, 
    [Address-PostalCode] VARCHAR(20) NOT NULL
  
)

CREATE TABLE CREDIT_CARDS (
    CCNumber VARCHAR(20) NOT NULL PRIMARY KEY,
    CCExpiration DATE NOT NULL,
    CVV VARCHAR(4) NOT NULL,
    Type VARCHAR(20) NOT NULL,
    Mail VARCHAR(200) NOT NULL
)
--POPULATE WITH DATA AT THIS POINT BAFORE FOREIGN KEYS
--FOREIGN KEY constraints
ALTER TABLE DETAILS
	ADD CONSTRAINT FK_ProductID FOREIGN KEY (ProductID)
	REFERENCES PRODUCTS(ProductID)

alter table DETAILS
	ADD CONSTRAINT FK_OrderID FOREIGN KEY (OrderID)
	REFERENCES ORDERS(OrderID)

ALTER TABLE PRICINGS
	ADD CONSTRAINT FK_MailStorePrice FOREIGN KEY (Mail) 
	REFERENCES STORES(Mail);

ALTER TABLE PRICINGS 
	ADD CONSTRAINT FK_ProductIDPrice FOREIGN KEY (ProductID)
	REFERENCES PRODUCTS (ProductID)

ALTER TABLE RESULTS
	ADD CONSTRAINT FK_IPAddress FOREIGN KEY (IPAddress, SearchDT)
	REFERENCES SEARCHES(IPAddress, SearchDT)

ALTER TABLE RESULTS
	ADD CONSTRAINT FK_ProductIDRes FOREIGN KEY (ProductID)
	REFERENCES PRODUCTS(ProductID);

ALTER TABLE ORDERS
	ADD CONSTRAINT FK_PhoneNumber FOREIGN KEY (PhoneNumber)
	REFERENCES RECIPIENTS(PhoneNumber)

ALTER TABLE ORDERS
	ADD CONSTRAINT FK_MailStore FOREIGN KEY (Mail)
	REFERENCES STORES(Mail)

ALTER TABLE ORDERS 
	ADD CONSTRAINT FK_CREDITCARD FOREIGN KEY (CCNumber)
	REFERENCES CREDIT_CARDS(CCNumber)

ALTER TABLE CREDIT_CARDS
	ADD CONSTRAINT FK_MailCustomerCredit FOREIGN KEY (Mail)
	REFERENCES CUSTOMERS(Mail)

ALTER TABLE SEARCHES 
	ADD CONSTRAINT FK_MailCustomerSearch FOREIGN KEY (Mail)
	REFERENCES CUSTOMERS(Mail)

ALTER TABLE REVIEWS 
	ADD CONSTRAINT FK_ReviewProductID FOREIGN KEY (ProductID)
	REFERENCES PRODUCTS (ProductID)

	
ALTER TABLE REVIEWS 
	ADD CONSTRAINT FK_MailCustomer FOREIGN KEY (Mail)
	REFERENCES CUSTOMERS (Mail)

--check constraints
ALTER TABLE STORES 
	ADD CONSTRAINT CK_StoreMail CHECK ( Mail like '%@%.%')

ALTER TABLE STORES 
	ADD CONSTRAINT CK_NumberOfShops CHECK (NumberOfShops>0)

ALTER TABLE STORES 
	ADD CONSTRAINT CK_StorePhone CHECK (Phone NOT LIKE '[^0-9]*$')


ALTER TABLE SEARCHES 
	ADD CONSTRAINT CK_IPAddress CHECK (IPAddress like '%.%.%.%')

ALTER TABLE CUSTOMERS
ADD CONSTRAINT CK_CustomersMail
CHECK (Mail LIKE '%@%.%')

ALTER TABLE CUSTOMERS
ADD CONSTRAINT CK_Password
CHECK (LEN(Password) >= 8)

ALTER TABLE ORDERS
ADD CONSTRAINT CK_Date
CHECK (WantedArrivalDate >= TransactionDT)

ALTER TABLE 	DETAILS		
ADD CONSTRAINT 	Ck_Quantity	
CHECK 		(Quantity > 0)

ALTER TABLE 	PRICINGS		
ADD CONSTRAINT 	Ck_Price	
CHECK 		(price > 0)

ALTER TABLE 	RECIPIENTS		
ADD CONSTRAINT 	Ck_PhoneNumber	
CHECK 		(PhoneNumber NOT LIKE '[^0-9]*$')

ALTER TABLE 	CREDIT_CARDS		
ADD CONSTRAINT 	Ck_CCNumber	
CHECK 		(CCNumber NOT LIKE '[^0-9]*$')

ALTER TABLE 	CREDIT_CARDS		
ADD CONSTRAINT 	Ck_CCExpiration	
CHECK 		(CCExpiration >= GETDATE())

ALTER TABLE CREDIT_CARDS 
	ADD CONSTRAINT CK_CVV
	CHECK (CVV  LIKE '[0-9][0-9][0-9]' OR CVV LIKE '[0-9][0-9][0-9][0-9]' )

--lookup table creating
CREATE TABLE [CC TYPE](
Type Varchar(20) NOT NULL PRIMARY KEY
)

CREATE TABLE [PRODUCT SIZE](
Size Varchar(10) NOT NULL PRIMARY KEY
)

CREATE TABLE [COUNTRIES](
Country VARCHAR(20) NOT NULL PRIMARY KEY
)

INSERT INTO [PRODUCT SIZE]
	VALUES ('LOW'),('MID'),('HIGH')
INSERT INTO COUNTRIES
SELECT DISTINCT Country
FROM STORES
INSERT INTO [CC TYPE]
	VALUES ('VISA'),('DISCOVER'),('AMEX'),('MASTERCARD')
ALTER TABLE CREDIT_CARDS 
	ADD CONSTRAINT FK_CCTYPE FOREIGN KEY (Type)
	REFERENCES [CC TYPE] (Type)

ALTER TABLE DETAILS 
	ADD CONSTRAINT FK_ProductSize FOREIGN KEY (Size)
	REFERENCES [PRODUCT SIZE] (Size)

ALTER TABLE STORES
	ADD CONSTRAINT FK_CountryStore FOREIGN KEY (Country)
	REFERENCES COUNTRIES (Country)
	
ALTER TABLE ORDERS 
	ADD CONSTRAINT FK_AdressCountry FOREIGN KEY ([Address-Country]) 
	REFERENCES COUNTRIES (Country)

--deleting all DB
drop table RESULTS

drop table PRICINGS

drop table DETAILS

drop table SEARCHES

drop table REVIEWS

drop table ORDERS

drop table RECIPIENTS

drop table CREDIT_CARDS

drop table STORES

drop table CUSTOMERS

drop table PRODUCTS

drop table COUNTRIES

drop table [CC TYPE]

drop table [PRODUCT SIZE]

-------------------------------------queries----------------------------------------------------------
--2 queries withoun nesting
SELECT s.Mail, s.Name, TotalQuantity=SUM(D.Quantity)
FROM STORES AS S JOIN ORDERS AS O ON S.Mail=O.Mail join DETAILS AS D ON D.OrderID=O.OrderID
	JOIN PRODUCTS AS P ON P.ProductID=D.ProductID
WHERE YEAR(O.TransactionDT)>=2020
GROUP BY S.mail, s.Name
HAVING COUNT(DISTINCT O.OrderID)>=5
ORDER BY TotalQuantity DESC

SELECT PR.ProductID, PR.Name,Avarage_Price=AVG(P.price)
FROM PRICINGS AS P JOIN PRODUCTS AS PR ON P.ProductID=PR.ProductID
GROUP BY PR.ProductID, PR.Name
ORDER BY Avarage_Price

--2 nested queries 
SELECT S.DeliveryArea
FROM STORES AS S JOIN 
	 ORDERS AS O ON S.Mail=O.Mail
WHERE S.DeliveryArea NOT IN ( SELECT ST.DeliveryArea 
				  FROM STORES AS ST JOIN 
					 ORDERS AS OD ON ST.Mail=OD.Mail 
				  WHERE DATEDIFF (YY, YEAR(OD.TransactionDT), GETDATE())=2
							  )
GROUP BY S.DeliveryArea
HAVING COUNT(DISTINCT O.OrderID)>=10

SELECT S.DeliveryArea,
	   AmountOfSales = COUNT (DISTINCT O.OrderID),
	   cast(COUNT (DISTINCT O.OrderID) AS FLOAT)/TOTAL.TotalOrders AS Ratio
FROM STORES AS S 
	 LEFT JOIN ORDERS AS O ON O.MAIL=S.MAIL
	 CROSS JOIN (SELECT TotalOrders = count (*)
				 FROM ORDERS
				 ) AS TOTAL
GROUP BY S.DeliveryArea, TOTAL.TotalOrders
ORDER BY Ratio DESC

--UPDATE QUERY
-- ADDING ATTRIBUTE
alter table customers
add [Customer-Rating] VARCHAR(1) NOT NULL DEFAULT 'C'

--SETTING NEW ATTRIBUTE
UPDATE CUSTOMERS
SET [Customer-Rating] = CASE 
    WHEN CLC.Ratio < 0.01 THEN 'C'
    WHEN CLC.Ratio >= 0.01 and CLC.Ratio < 0.05 THEN 'B'
    ELSE 'A'
END
FROM (
    SELECT 
        CU.Mail, 
        Ratio = SUM(DE.Quantity * P.Price) / TotalRevenue.TotalRevnue
    FROM 
        CUSTOMERS as CU  JOIN CREDIT_CARDS as CC on CU.Mail = CC.Mail
         JOIN ORDERS as O on O.CCNumber = CC.CCNumber 
         JOIN DETAILS as DE on O.OrderID = DE.OrderID
         JOIN  PRICINGS as P on DE.ProductID = P.ProductID and O.Mail = P.Mail
         CROSS JOIN 
        (SELECT SUM(DE.Quantity * P.Price) AS TotalRevnue
         FROM ORDERS as O 
         JOIN DETAILS AS DE ON O.OrderID = DE.OrderID
         JOIN PRICINGS AS P ON DE.ProductID = P.ProductID and O.Mail = P.Mail
        ) AS TotalRevenue
    GROUP BY CU.Mail, TotalRevenue.TotalRevnue
    ) AS CLC
WHERE CUSTOMERS.Mail = CLC.Mail

--EXCEPT QUERY 
SELECT P.ProductID, P.Name, AVGPRICINGS.Price
FROM PRODUCTS AS P
     JOIN RESULTS AS R ON P.ProductID=R.ProductID
	 JOIN (SELECT PRODUCTS.ProductID, PRICE=AVG(PRICINGS.PRICE)
	       FROM	  PRODUCTS JOIN PRICINGS ON PRICINGS.ProductID=PRODUCTS.ProductID
		   GROUP BY PRODUCTS.ProductID) AS AVGPRICINGS ON AVGPRICINGS.ProductID=P.ProductID
WHERE AVGPRICINGS.Price > ( SELECT AVG(Price)
				   FROM PRICINGS
				 )
GROUP BY P.ProductID, P.Name, AVGPRICINGS.Price
HAVING COUNT(*)>=3

EXCEPT

SELECT P.ProductID, P.Name, AVGPRICINGS.Price
FROM ORDERS AS O
	 JOIN DETAILS AS D ON O.OrderID=D.OrderID 
	 JOIN PRODUCTS AS P ON P.ProductID=D.ProductID
	 JOIN (SELECT PRODUCTS.ProductID, PRICE=AVG(PRICINGS.PRICE)
	       FROM	  PRODUCTS JOIN PRICINGS ON PRICINGS.ProductID=PRODUCTS.ProductID
		   GROUP BY PRODUCTS.ProductID) AS AVGPRICINGS ON AVGPRICINGS.ProductID=P.ProductID 
GROUP BY P.ProductID, P.Name, AVGPRICINGS.Price

--WINDOWS FUNCTIONS 
--DANCE_RANK
SELECT P.ProductID, P.Name, PR.Price, 
	   RankingPrice = DENSE_RANK() 
					  OVER (ORDER BY PR.Price)
FROM PRODUCTS AS P 
	 JOIN PRICINGS AS PR ON PR.ProductID=P.ProductID
ORDER BY RankingPrice

--LAG
SELECT  PRODUCTS_FREQUENCY.ProductID, PRODUCTS_FREQUENCY.Name,
		AVG(PRODUCTS_FREQUENCY.DaysFromPrev) AS AvgGap 
FROM (SELECT P.ProductID, P.Name ,
	         DaysFromPrev = DATEDIFF (DD, LAG (O.TransactionDT,1)
						 OVER (PARTITION BY P.ProductID
						 ORDER BY O.TransactionDT),O.TransactionDT)
      FROM PRODUCTS AS P 
          JOIN DETAILS AS D ON D.ProductID=P.ProductID
	   JOIN ORDERS AS O ON O.OrderID=D.OrderID
	 ) AS PRODUCTS_FREQUENCY
GROUP BY PRODUCTS_FREQUENCY.ProductID, PRODUCTS_FREQUENCY.Name 
ORDER BY AvgGap

--NTILE
SELECT SALES_AMOUNT.Mail, SALES_AMOUNT.Name,
	   SalesGroup = NTILE (5)
				    OVER (ORDER BY  AmountOfSales)
FROM (SELECT S.Mail, S.Name,  
            AmountOFSales = COUNT(*) 
	  FROM STORES AS S 
               LEFT JOIN ORDERS AS O ON S.Mail=O.Mail
	  GROUP BY S.Mail, S.Name
	  ) AS SALES_AMOUNT

--LAST_VALUE
SELECT LasPurCalc.Mail, LasPurCalc.FullName,CAST( LasPurCalc.LastPurchase AS DATE)
FROM (SELECT C.Mail, FullName=C.[Name-First]+' '+C.[Name-Last],
	   LastPurchase = LAST_VALUE (O.TransactionDT)
	   OVER (PARTITION BY C.Mail
		     ORDER BY O.TransactionDT
			 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
			 ) 
FROM CUSTOMERS AS C 
	 JOIN CREDIT_CARDS AS CC ON CC.Mail=C.Mail
	 JOIN ORDERS AS O ON O.CCNumber=CC.CCNumber) AS LasPurCalc
GROUP BY LasPurCalc.Mail, LasPurCalc.FullName, LasPurCalc.LastPurchase

--WITH CLAUSE
WITH 
INCOME_PER_ORDER AS (SELECT Mail=O.Mail, OrderID= O.OrderID, TotalPrice=SUM(D.Quantity*P.Price)
						 FROM ORDERS AS O join DETAILS AS D ON D.OrderID=O.OrderID
						      JOIN PRICINGS AS P ON P.Mail=O.Mail AND D.ProductID=P.ProductID   
						 GROUP BY O.Mail, O.OrderID 
					),

STORE_RATIO AS (SELECT IPR.Mail,SUM(IPR.TotalPrice)/TOTAL.TotalIncome AS StoreRatio 
				FROM INCOME_PER_ORDER AS IPR CROSS JOIN ( SELECT TotalIncome= SUM(TotalPrice)
															FROM INCOME_PER_ORDER
													     ) AS TOTAL 
				GROUP BY IPR.Mail,TOTAL.TotalIncome  
				),

AVG_MONTHLY_INCOME AS (SELECT IPR.Mail, SUM(IPR.TotalPrice)/COUNT (DISTINCT MONTH(O.TransactionDT)) AS AvgMonthlyIncome  
						FROM INCOME_PER_ORDER AS IPR JOIN ORDERS AS O ON IPR.OrderID=O.OrderID
						GROUP BY IPR.Mail
						),

PURCHASED_QUANTITY AS ( SELECT O.Mail,D.ProductID,P.Name, TotalPurchased=SUM (D.Quantity)
						 FROM ORDERS AS O JOIN DETAILS AS D ON D.OrderID=O.OrderID 
							  JOIN PRODUCTS AS P ON P.ProductID=D.ProductID 
						 GROUP BY O.Mail, D.ProductID, P.Name
						 ),

MAX_PURCHASED AS (  SELECT MAIL,PRODUCT= LAST_VALUE(NAME) 
											OVER (PARTITION BY MAIL ORDER BY TotalPurchased )  
					FROM PURCHASED_QUANTITY
					
				),	
					
INCOME_DETAILS AS ( SELECT AVI.AvgMonthlyIncome, SR.StoreRatio, AVI.Mail 
					FROM AVG_MONTHLY_INCOME AS AVI JOIN STORE_RATIO AS SR ON AVI.Mail=SR.Mail 
					),

LAST_SALE AS ( SELECT MAIL, LastSaleDate= LAST_VALUE (TransactionDT)
														OVER (PARTITION BY mail order by transactiondt)
			   FROM ORDERS
			   )


SELECT S.Name, S.Mail, ID.AvgMonthlyIncome,SalesRatio= ID.StoreRatio,LargestOrderPrice=MAX(IPR.TotalPrice),
		TopPurchasedProduct= (SELECT TOP 1 PRODUCT
							  FROM MAX_PURCHASED AS MP
							  WHERE MP.Mail=S.Mail
							  ),
		LastSaleGap= DATEDIFF (DD, (SELECT TOP 1 LS.LastSaleDate
													FROM LAST_SALE AS LS
													WHERE S.MAIL=LS.Mail ), GETDATE())		
FROM STORES AS S join INCOME_DETAILS AS ID ON ID.Mail=S.Mail 
	  join INCOME_PER_ORDER AS IPR ON IPR.Mail=S.Mail
GROUP BY S.Name, S.Mail, ID.AvgMonthlyIncome, ID.StoreRatio
ORDER BY LastSaleGap


